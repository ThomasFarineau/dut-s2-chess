package pieces;

public class Pion extends Piece {
	
	public Pion(boolean couleur) {
		super(couleur);
	}
	public String toString() {
        if(getCouleur())
            return"Pn";
        else
            return"Pb";
    }
}
